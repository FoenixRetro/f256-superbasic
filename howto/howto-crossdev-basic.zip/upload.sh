#
#		Script for Linux to run a BASIC program.
#
python fnxmgr.zip --port /dev/ttyUSB0  --binary $1 --address 28000
