#
#		Script for Linux to update F256Jr BASIC & Kernel
#
python fnxmgr.zip --port /dev/ttyUSB0  --binary $1 --address 28000
